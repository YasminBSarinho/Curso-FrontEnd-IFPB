Paleta de cor: https://color.adobe.com/pt/search?q=food&page=2
Imagens: https://unsplash.com/pt-br
